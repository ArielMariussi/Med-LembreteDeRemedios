self.assetsManifest = {
  "version": "bFQs/wN/",
  "assets": [
    {
      "hash": "sha256-O176SgsxKdRgfuUtTYS/NM4zfy/MJInAIqvU7oV40VI=",
      "url": "Med.Web.styles.css"
    },
    {
      "hash": "sha256-kJXKqRCleT/Jk1wJUhUu24r2LAA7IWVYmdoENizE38M=",
      "url": "_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"
    },
    {
      "hash": "sha256-3KcDYuGo+8FxjxqYqdXrWsZtqJ+DrVHskSudHvcp/Kc=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-FZzvCgyLKmiHQQMfmYMLP1xUaWrGeuldIJbHbji27xA=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-Vjua55xDXd8szlqfHvJivxyKBsDcln0rUtBnWVhwz9Q=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-g6sGHJp8IcCFAZiVfERVm7OpLvShcAcGQLvcWipI8jU=",
      "url": "_framework/Med.Core.dwrxxq6q6b.pdb"
    },
    {
      "hash": "sha256-3RqCKAIw7i4fRS+yTqL9iRCKM0+0PtL1nOBuDnUQWuY=",
      "url": "_framework/Med.Core.hz6meg83e0.wasm"
    },
    {
      "hash": "sha256-F/Yo7qeGs17A0X/yb6xtaaaWPwdRCaVb0BblNtoxUPY=",
      "url": "_framework/Med.Web.tfro5hyxii.wasm"
    },
    {
      "hash": "sha256-QfQvy91WcFn/dYhKKQYmbWZ+Pp6rlNcUKzz0///IBGw=",
      "url": "_framework/Med.Web.zjbxj491ho.pdb"
    },
    {
      "hash": "sha256-vVLejdOiMlFx8IGHZP8QkMiuljqOBamn7aeI0sX1pao=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.9taw8vfmpb.wasm"
    },
    {
      "hash": "sha256-DojMzrGpaM1QcSUyojcQt5JzXfydwmCQI5Mtm0Tmsjs=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.ekrqawzihh.wasm"
    },
    {
      "hash": "sha256-oUow/K4FtQzRSPmPCKCQPoxAd7bOXvAqI4K6R0SXTsA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.7uy44evjjv.wasm"
    },
    {
      "hash": "sha256-OHr7oQjvO9tcg30Qgwc84Pf3PG/ctnLrMQLFnTXzAyY=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.4tycnul1zm.wasm"
    },
    {
      "hash": "sha256-r8IMdqRMgO7LPB3hPQ8tQ+Wv8JZUrBA0n0BOTBxBGLs=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.1sa732in15.wasm"
    },
    {
      "hash": "sha256-FyNQY34+mDXz3X6OS1uq6hGWvllW8A8AMRpBcmAoFnQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.Authentication.1ezneva6is.wasm"
    },
    {
      "hash": "sha256-oJ49iG7wXL1fniWCVEVSNRjDkMcZMYTBt0ZAMut03+Y=",
      "url": "_framework/Microsoft.AspNetCore.Components.kr0rm7hoa3.wasm"
    },
    {
      "hash": "sha256-U2fwS06Jg+OBinD2rxBCRWQKhhWF2F7SxcOJLnSfmHg=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.1joqye40si.wasm"
    },
    {
      "hash": "sha256-fHdXMBuT8VQwuYPTLam5h48nseyD1A8h24mSMdjXZyA=",
      "url": "_framework/Microsoft.CSharp.42nruzkdkt.wasm"
    },
    {
      "hash": "sha256-J1534OPAkv/Z9yVLIAzdgw4OGS8n32RP6Ho07JDo56E=",
      "url": "_framework/Microsoft.Extensions.Configuration.9cy8m345v7.wasm"
    },
    {
      "hash": "sha256-FvnPEaM27ZfXlc9eWjtfFsPVhPzgX6OztvP16zt0jUE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.iqvlnrn91q.wasm"
    },
    {
      "hash": "sha256-LJoQrwOf0/LapnCqLwhqu0/I7ZQiKgUxLT01Ef5lG5w=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.cutjcveon1.wasm"
    },
    {
      "hash": "sha256-gnyfkzbvVX0BuYBPvh9jo3Ir+MQh5qzlRGMqtnQ6WiM=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.2cd4oe9rok.wasm"
    },
    {
      "hash": "sha256-wKiPPRjkteQLWFVTXkrk92guyWdvaSn6nlgXLdEReYw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.08a4wzhg8u.wasm"
    },
    {
      "hash": "sha256-PK+I5AqeZACKa49ElY3daRJx+dzB0WROpI4dup5XlXo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.gdq1ti9fi8.wasm"
    },
    {
      "hash": "sha256-ExedezHG3IzAbwZrMKLnE7kz2LESvrz/TEzkfW0HYBs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.t4ojowtauq.wasm"
    },
    {
      "hash": "sha256-O2goVX+Xia/HpW9e3mbcS0kY6owLF81xYKZT28epqb0=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.1pkgzailem.wasm"
    },
    {
      "hash": "sha256-DjpSP+lRN10gdOjFl9J55aHQL+habTiiDC1CeEiDhLU=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.i74bcpwzgm.wasm"
    },
    {
      "hash": "sha256-RHPF1kNXj4qNQg478jctDDbkYgxpT6kUDUUmtNSHdK4=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.socmvxw8xz.wasm"
    },
    {
      "hash": "sha256-nR2DtAHQRgEKOdEyzDe7zo8qG5p55sVj22Bs8H+W+x8=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.dwth4q8v12.wasm"
    },
    {
      "hash": "sha256-L4oked4Fv62X0nnMtEPPe3p4bhhxxJF5SfRJDxXMtY0=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.9qyocthipm.wasm"
    },
    {
      "hash": "sha256-PjQNiYsAWF/cK95vMaW5WGbC1CTEXgEJRNGrSDi+Ulc=",
      "url": "_framework/Microsoft.Extensions.Http.qefrl44lvx.wasm"
    },
    {
      "hash": "sha256-GJNjpp2mlMIYboBhzukWw5r2Z24PsB0E9Gj9VoTGKEI=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.o4jp2hcm79.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-qs4GD6kFKd9ksQxTpXPBf+OVyk014JKTKB7+tzT7FFE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.22il4fuit4.wasm"
    },
    {
      "hash": "sha256-+x/gFzLju5dzkUVns/OJdyVx6RhlmRe0op7uvuYKvZg=",
      "url": "_framework/Microsoft.Extensions.Logging.nh0qjqoup9.wasm"
    },
    {
      "hash": "sha256-KYqulprInBMwPgXPTCaUULAKPr9d21QsF0aQlLcuHAs=",
      "url": "_framework/Microsoft.Extensions.Options.9sfln8juj8.wasm"
    },
    {
      "hash": "sha256-1zJCghH8zfyEYaV8TFypZ1goNwxg1r0uO6TpK3eN7ao=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.tn1jqxkqnw.wasm"
    },
    {
      "hash": "sha256-ZEIzxGJFBrKMSveUDfnK24vuyMuxnIt3dchYnhBAXWA=",
      "url": "_framework/Microsoft.Extensions.Primitives.c4s15t4yil.wasm"
    },
    {
      "hash": "sha256-9dAjljgkpc26ys+VBDilPgkark902bTSQzJ5hryvYDQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.ntyvhbvn6b.wasm"
    },
    {
      "hash": "sha256-eq52mJf717lcpCglRh/wZKVgYAHIaYegE8qvApOYvqY=",
      "url": "_framework/Microsoft.JSInterop.e7f2xti27k.wasm"
    },
    {
      "hash": "sha256-kGQHJNyOxVUzH6Ci/S8DxZPUjWwI7HFdStMiLRfvWDw=",
      "url": "_framework/Microsoft.VisualBasic.4vzo9ck06b.wasm"
    },
    {
      "hash": "sha256-cBBKlOfrEV/1xfjZwNxoPGwo7K7q5v6X2LqgawuJ/Vk=",
      "url": "_framework/Microsoft.VisualBasic.Core.4bggtv24el.wasm"
    },
    {
      "hash": "sha256-iuXz4OxR6V6INjyXMG1kTkMob4YGNIupybctsz9bY2M=",
      "url": "_framework/Microsoft.Win32.Primitives.y13gzhgb17.wasm"
    },
    {
      "hash": "sha256-tSFnBHIvQUoLdm/N+r4ILHdVyiL/OReONp3LeoEuOPI=",
      "url": "_framework/Microsoft.Win32.Registry.tyhjour9kq.wasm"
    },
    {
      "hash": "sha256-JNYdRa7suT0EhCubSWGzXMj5VX0+bH0DPZVI5eXjG60=",
      "url": "_framework/MudBlazor.09mms412e3.wasm"
    },
    {
      "hash": "sha256-ID2O84s1i37WyD3VGwC+wZ0hgSa+12L3WJ9sbdqi+7c=",
      "url": "_framework/System.AppContext.s1m5cqdrdd.wasm"
    },
    {
      "hash": "sha256-01Ols37CVTSZSP6EgL6ibEF0+JMZ/TU2TjfLVtXR1As=",
      "url": "_framework/System.Buffers.1j417u4kuo.wasm"
    },
    {
      "hash": "sha256-2sC42HDBq8vKKaubmXUCyw8/wvdhOMt328yZkDF0m9o=",
      "url": "_framework/System.Collections.2t5b918uez.wasm"
    },
    {
      "hash": "sha256-eMFKPA01mc6dmJqi7JfQYgMeiK7kVTDzYgylqN1dvug=",
      "url": "_framework/System.Collections.Concurrent.snjod2tykt.wasm"
    },
    {
      "hash": "sha256-+sy4McqvJnMpCurKOrkCd/5S07Qpu2XoevK66F3ZVs4=",
      "url": "_framework/System.Collections.Immutable.a0vgswjysf.wasm"
    },
    {
      "hash": "sha256-nOMSc1mLZ+aftlyjmwjMwyK8DVim7QSFGCFMoCg0gyk=",
      "url": "_framework/System.Collections.NonGeneric.su14uvk5zu.wasm"
    },
    {
      "hash": "sha256-D6JnfrbNsdzAmqXxWfwvX0mGhWiIckCF8XxegDln+aQ=",
      "url": "_framework/System.Collections.Specialized.t1vf30ruad.wasm"
    },
    {
      "hash": "sha256-tf5nlovVb/wv2icNjoHEFE7gWGFTEFVGp4ANIrrYCbc=",
      "url": "_framework/System.ComponentModel.Annotations.158mot4hah.wasm"
    },
    {
      "hash": "sha256-x8P3MPG0KtM1rYzas4plycxsxxjGJJSFkdHBZ5WWo+M=",
      "url": "_framework/System.ComponentModel.DataAnnotations.r34g710t1g.wasm"
    },
    {
      "hash": "sha256-bIbiNp4/SAMIRNU/hDLKq6SyZ4CMA7tkq3Dakqf3tK8=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.skwithjnzs.wasm"
    },
    {
      "hash": "sha256-PpwnSmnyx9y4S9LjH/Ow+n1R+xrrHMWBHgptIuz9EJQ=",
      "url": "_framework/System.ComponentModel.Primitives.mj8uhnvq5s.wasm"
    },
    {
      "hash": "sha256-oFlNbzvaFTr6N8DqbNCJSclOWiOI7fRY0leN1ojmpv8=",
      "url": "_framework/System.ComponentModel.TypeConverter.k79n4l6b5k.wasm"
    },
    {
      "hash": "sha256-1tuhHT7wnaMPyWE6juL2D24prvDf+4S5fV/LKdF+HoQ=",
      "url": "_framework/System.ComponentModel.uu49rsf6yh.wasm"
    },
    {
      "hash": "sha256-g/JURhlZ/j9oq5Mq9faOE+KBjBEfuxPjl7mEF/xHebE=",
      "url": "_framework/System.Configuration.fx5qu5whwq.wasm"
    },
    {
      "hash": "sha256-/DI7gV1531uDKzXbPkm//U9MlxVfWbRY1yc0uGhmbqI=",
      "url": "_framework/System.Console.syamw71pz0.wasm"
    },
    {
      "hash": "sha256-uYo1GZHUBz3myDKmJ0hJ5jnR/kY5DgQMbOOmihZL2dQ=",
      "url": "_framework/System.Core.jd6ciyf32b.wasm"
    },
    {
      "hash": "sha256-byAUARaqqRyqFj9J7aGOdaPSP/qYRBNVWRHLfLfaQNU=",
      "url": "_framework/System.Data.Common.d1yt6etc0m.wasm"
    },
    {
      "hash": "sha256-uFesJQAOdYwnMCPDFzySL0TmG4TjWAKYnLbSqPN8Kt0=",
      "url": "_framework/System.Data.DataSetExtensions.4pnvaxy5ne.wasm"
    },
    {
      "hash": "sha256-X4WhieHD118YXfy0r9yaWjoGZDiRTUGDcYgjP0+2900=",
      "url": "_framework/System.Data.ne1dd0hox9.wasm"
    },
    {
      "hash": "sha256-SRcQMlzEsoM5+dHgClkg3lqUxR2zPibObA69/gT38ME=",
      "url": "_framework/System.Diagnostics.Contracts.9k7kcy6gms.wasm"
    },
    {
      "hash": "sha256-UPydIFpMtVb9bw36hjrtSpV9WXOWahvpjVXLemBAaKI=",
      "url": "_framework/System.Diagnostics.Debug.c9q7byplx9.wasm"
    },
    {
      "hash": "sha256-O2pLRBwBrelMyzuvFeXuQ6AG5vKTXTxQ2zlPh9SPJKY=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.f7rmncx401.wasm"
    },
    {
      "hash": "sha256-+UPlRJQW/gRFZHZqBtCqsYshKOM48f3DZf2w5OiAaxI=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.xemm1mjp7a.wasm"
    },
    {
      "hash": "sha256-d/nUWBJxULqHakgxmJbmn7ifZENDb5BUQi9PnyKUySs=",
      "url": "_framework/System.Diagnostics.Process.1qino8xg16.wasm"
    },
    {
      "hash": "sha256-G5O3PgwzPgsSsnGKyEYEuDT+4cfjpRcH9tjIKrZpo5s=",
      "url": "_framework/System.Diagnostics.StackTrace.3uegwd3lhl.wasm"
    },
    {
      "hash": "sha256-9/eYPovoJIiblmbFBA6U/ZMCzv3bwzrLXn8+fA+IXYE=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.5hi2izsni5.wasm"
    },
    {
      "hash": "sha256-Z+6TxKgUtIraVz8n2Coc2Cro8CWA00LhjfVjJpx2N18=",
      "url": "_framework/System.Diagnostics.Tools.x6iein3aw5.wasm"
    },
    {
      "hash": "sha256-/CCBc6KSog/u56Na84GbJZUz3+KRUR/AUhJDAMAToIc=",
      "url": "_framework/System.Diagnostics.TraceSource.40k3fagmbv.wasm"
    },
    {
      "hash": "sha256-E9VB38bW9/HtxvSnPCFVKtOE/VV+t3dheZGzkEOU6pQ=",
      "url": "_framework/System.Diagnostics.Tracing.xfrk7rbs8k.wasm"
    },
    {
      "hash": "sha256-5Ymtt42ZCeh/VPB7sob76iB3IhgTKma4C9qMuzB+Nbk=",
      "url": "_framework/System.Drawing.Primitives.pfbshcoq2m.wasm"
    },
    {
      "hash": "sha256-UlmulMOBrd2+jzIFxDnunjpx46cauq1219uSR+tiEK0=",
      "url": "_framework/System.Drawing.mqfwfcrbrr.wasm"
    },
    {
      "hash": "sha256-GGnqUlG8KljmG4lXwiPxC5Cy4PTqa7bD85Jrhz2nqHk=",
      "url": "_framework/System.Dynamic.Runtime.gu6hiigqlh.wasm"
    },
    {
      "hash": "sha256-GsxnwEig3hpMmcf9nd+1//Sm47TjQcNTymDXczUcVm0=",
      "url": "_framework/System.Formats.Asn1.yekfn8q2e6.wasm"
    },
    {
      "hash": "sha256-OaC9Ue5edQdJqGZg5V2V5VhzsrX0AaGJzvRkk6WVBYQ=",
      "url": "_framework/System.Formats.Tar.tnqx7pnrxf.wasm"
    },
    {
      "hash": "sha256-srbXKNplKmyESgYV5b0F4Ib3Ro19BsL7DLUBorDss1M=",
      "url": "_framework/System.Globalization.Calendars.i7onzf5m6j.wasm"
    },
    {
      "hash": "sha256-4ebIovEfQ66LIAneipfoV/LZi3P/zYdtFv1YeAHG1D4=",
      "url": "_framework/System.Globalization.Extensions.bp1mb3pgx4.wasm"
    },
    {
      "hash": "sha256-pWWuSAdMUKJuRl1L42U3TuH0MQ6XGBygaZrxE9xjcfE=",
      "url": "_framework/System.Globalization.ty0vn6s1zt.wasm"
    },
    {
      "hash": "sha256-F2KcbzzcKVkfzyVleySYAqOzBCBBQ9/DS7OotOxU9fA=",
      "url": "_framework/System.IO.Compression.Brotli.7sy4pc7w3d.wasm"
    },
    {
      "hash": "sha256-FYLJT/+Z8KIbtn/zKqMO+M7ugIzXU5sYZaUQyexDKTw=",
      "url": "_framework/System.IO.Compression.FileSystem.ti3tzu5xvt.wasm"
    },
    {
      "hash": "sha256-Tj7pHCQzZly7vc3djmDf+FMy+wfuSVTJ2qDSakKiaqo=",
      "url": "_framework/System.IO.Compression.ZipFile.2s8hnxmuzt.wasm"
    },
    {
      "hash": "sha256-Axnr96eU0arIPmXOCKt0b4iLYK50qcw9DfIpDoaCY38=",
      "url": "_framework/System.IO.Compression.p1g7yu0ce8.wasm"
    },
    {
      "hash": "sha256-D4mcJy9UcdmJ/mCGyjuCylgKy8sy8Q83g/kOlSMIH0k=",
      "url": "_framework/System.IO.FileSystem.1opca4l93w.wasm"
    },
    {
      "hash": "sha256-FZNUWrEzrZbR2vNwdqOhqVSsd3Z4lAKWGLnf18yhWNY=",
      "url": "_framework/System.IO.FileSystem.AccessControl.3mppn26g4p.wasm"
    },
    {
      "hash": "sha256-LK7ycPf4hduX4k7jF9nm2MXRRVLklFr0DVI4xb4NaD4=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.01bk9xhkgf.wasm"
    },
    {
      "hash": "sha256-ZBZmtYtCziKksNizg8px1SMMkVLr7piRv3WDBIRPXOs=",
      "url": "_framework/System.IO.FileSystem.Primitives.so20cwlipv.wasm"
    },
    {
      "hash": "sha256-RHlsAllw8CKGoZrbvSIXfzXkmCzARuS2KjtIzWN+l6g=",
      "url": "_framework/System.IO.FileSystem.Watcher.8d23w6q7ux.wasm"
    },
    {
      "hash": "sha256-453jjM90Q4IsypgghAOO6/i/7i1Hvg9DrK3nMDUcVpc=",
      "url": "_framework/System.IO.IsolatedStorage.7fgnb0ws8g.wasm"
    },
    {
      "hash": "sha256-Louqy24NjwR75eWt4FWoNlHXXSRxyaHzWsXlptBb4Eo=",
      "url": "_framework/System.IO.MemoryMappedFiles.ibpwrycr0s.wasm"
    },
    {
      "hash": "sha256-aGqAJ5IFHJYjM6FkdyxSYtiYl3SiJ5oM+w3A0LEvqC4=",
      "url": "_framework/System.IO.Pipelines.c7q33khou2.wasm"
    },
    {
      "hash": "sha256-ObbpUfPeM8Y08s9e7NVxrCaxtw7R+FfvX6ABE9EDzOg=",
      "url": "_framework/System.IO.Pipes.AccessControl.tfwwyqsetj.wasm"
    },
    {
      "hash": "sha256-dkkRNyx1mVTFRr/us2o9JrunCpP9krODMB0mrm4md5Y=",
      "url": "_framework/System.IO.Pipes.a8uajzmlpn.wasm"
    },
    {
      "hash": "sha256-LILtn3Q8u1HsKWbZnIelgaZaxY+gP4pIqAUYkkkxBEQ=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.83yl6yt2iz.wasm"
    },
    {
      "hash": "sha256-4myKiJWU4dAagVf4I/gNO68u/TDrRsqp49FmkAg/FF4=",
      "url": "_framework/System.IO.e1zqtvaalv.wasm"
    },
    {
      "hash": "sha256-7Lr43xww4e/KDjVnm7wz0JUad0m6OZd9oXy4E0QmcRc=",
      "url": "_framework/System.Linq.Expressions.4k0xcmud1d.wasm"
    },
    {
      "hash": "sha256-68hpWhllBTcY6piVVhkibowxhLgS0CXgOB7lPZ/VuyI=",
      "url": "_framework/System.Linq.Parallel.r87llb7okq.wasm"
    },
    {
      "hash": "sha256-gxU527b3MUTGOXaa0ZwtW7NvII1qU49iQVQjM7aUFug=",
      "url": "_framework/System.Linq.Queryable.hfxpxp7tmk.wasm"
    },
    {
      "hash": "sha256-M5JLGfVtlWGw6srfMWONEsMIj/eQeHs87FV4aewaiV4=",
      "url": "_framework/System.Linq.twjwl36fvx.wasm"
    },
    {
      "hash": "sha256-mtiru2MsLfJhuJGI/VeywMXElGRSWyK/pJmR9Rg7QxE=",
      "url": "_framework/System.Memory.a09kq5q1wq.wasm"
    },
    {
      "hash": "sha256-5IhwuQyiZvMOzgNNUSSxDhbZ1jxsKiAw0opiR9a13Rg=",
      "url": "_framework/System.Net.0lvglk8w9j.wasm"
    },
    {
      "hash": "sha256-YdJ1LFlknhPMS7vTGus5fGjuhcPqhN6NjSU5Ao0eeQM=",
      "url": "_framework/System.Net.Http.Json.jj6yc3emul.wasm"
    },
    {
      "hash": "sha256-5ehf6HoGZLhoVO6YHykARRoWpSO5YOcp5AL9mKaxeMc=",
      "url": "_framework/System.Net.Http.h9xaaq7jnl.wasm"
    },
    {
      "hash": "sha256-SmcWK1RuDKLmKA3AdTeoO/lrtnZdxkAfRzeLA9TucqM=",
      "url": "_framework/System.Net.HttpListener.an7gma990e.wasm"
    },
    {
      "hash": "sha256-CpUUCkk6t6zN4/rKfFvw+xkoBM2s1zSl45fNPFgiekQ=",
      "url": "_framework/System.Net.Mail.u6wgsy4z9w.wasm"
    },
    {
      "hash": "sha256-y5yKHivw6IhzCOHWnIeoIy9TbxYksIEEmIQsPXS2mRE=",
      "url": "_framework/System.Net.NameResolution.rwbqukfhy3.wasm"
    },
    {
      "hash": "sha256-NEWnQ50MlEFX86Qwr6AX5lpNKc31+VZR0axoMq5iysk=",
      "url": "_framework/System.Net.NetworkInformation.8j84xwkntc.wasm"
    },
    {
      "hash": "sha256-tuV+OysIrsd6N5LRR6RCwR/vcLevlIssIBseDWPcY6A=",
      "url": "_framework/System.Net.Ping.e2m8o3gbwx.wasm"
    },
    {
      "hash": "sha256-8Ffjtv+aJ8rz6TTWfXiToWGPRfVv0vduekO/+v03YXg=",
      "url": "_framework/System.Net.Primitives.goyaq8250w.wasm"
    },
    {
      "hash": "sha256-1Qa0NFbX22iz6OIobxs4877ejcx5KQQ12oo8hnbSszc=",
      "url": "_framework/System.Net.Quic.71kz59o13e.wasm"
    },
    {
      "hash": "sha256-GrJ9OHviyzV/IME0/lEn90IX3w9jMHEmSvNYGxpZ+6Q=",
      "url": "_framework/System.Net.Requests.y66rub3dmq.wasm"
    },
    {
      "hash": "sha256-pcE1PbbqQ7ZyJHZwbYCG+aIU3TJ0XgsKtR3At85bGj0=",
      "url": "_framework/System.Net.Security.9nm4itdnxl.wasm"
    },
    {
      "hash": "sha256-n01oPGpkt3FqTRke2iCqfzakRlEXpQqNeiLYlut/Z1Y=",
      "url": "_framework/System.Net.ServicePoint.3v05yui8ph.wasm"
    },
    {
      "hash": "sha256-TEMnxyvlexP8s+RFpjPrbTqknTn5HR22UmPhf0L7cdY=",
      "url": "_framework/System.Net.Sockets.s2hlz4y33k.wasm"
    },
    {
      "hash": "sha256-YXNfrNjFT3RNXjDYuYg4II7fjz9S68PnYWcakHjs254=",
      "url": "_framework/System.Net.WebClient.lj2iuapn7c.wasm"
    },
    {
      "hash": "sha256-qWWzS3QKalbVesvqwQk93sV8gi/X3wsNeF/Vb0avdqM=",
      "url": "_framework/System.Net.WebHeaderCollection.z5wivq0knn.wasm"
    },
    {
      "hash": "sha256-tw9LfOdr7pLHXjP3/ZkiLzGgfE9i2eyGaMrl9Z3S4NI=",
      "url": "_framework/System.Net.WebProxy.943aehpmoe.wasm"
    },
    {
      "hash": "sha256-6qfPGphS65Qw2wb2Y4piUMhx5tDug64OWCrIFab3tc4=",
      "url": "_framework/System.Net.WebSockets.Client.6dpq11euqo.wasm"
    },
    {
      "hash": "sha256-7dFPE75reqxaKcVeUCellOzNXciMsfwIeKbi+KCfCD4=",
      "url": "_framework/System.Net.WebSockets.d4tqwbd78d.wasm"
    },
    {
      "hash": "sha256-tY3byAQvYlUT6zOwv1VPfAS8gGzEKoHEeap35hBFNgI=",
      "url": "_framework/System.Numerics.1t6duje1u6.wasm"
    },
    {
      "hash": "sha256-qYsWYuERgwcvBkf2uooZ0i/4YfTV55a/gMN2PiEeemk=",
      "url": "_framework/System.Numerics.Vectors.9cv8judt5d.wasm"
    },
    {
      "hash": "sha256-P3YlDKjtduaZZbe54TVtKpWy4IioxMBRp+iQYQSHgL0=",
      "url": "_framework/System.ObjectModel.ttxa0wcei0.wasm"
    },
    {
      "hash": "sha256-41nae2p7dygOHEv3upnee/kVsa3Dg6SHV+ePzgy66j0=",
      "url": "_framework/System.Private.CoreLib.f5mfssf3vz.wasm"
    },
    {
      "hash": "sha256-hP/5GpOQZpWtee5depJAn6zTHYPnWOEF35KEU6YXXnA=",
      "url": "_framework/System.Private.DataContractSerialization.s0q7ln5lfv.wasm"
    },
    {
      "hash": "sha256-yPDcBmbiygxJfX5R0AW1tBM2eslEI+llzeAKd8/QsdI=",
      "url": "_framework/System.Private.Uri.cjhkfbq9hk.wasm"
    },
    {
      "hash": "sha256-ZysZMaJKyPqaTw4BHUDoQ9fH0knm8aflfHT/wXK0yvU=",
      "url": "_framework/System.Private.Xml.94ouvkrot6.wasm"
    },
    {
      "hash": "sha256-uufKb7jKU7XykhApF79ynByVaYeylG12x0+hqGrvbe4=",
      "url": "_framework/System.Private.Xml.Linq.eirwdqbh8r.wasm"
    },
    {
      "hash": "sha256-kM4Qd8pAqM9nlxlNxP3+pyNPrVpUhAFohFOH49XXGL8=",
      "url": "_framework/System.Reflection.DispatchProxy.w4usnwlger.wasm"
    },
    {
      "hash": "sha256-g85bY8Ra5hxaZ5Et/jqftKPT1uM0DybktPpAUd9HW4A=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.r26fuxs58n.wasm"
    },
    {
      "hash": "sha256-2iMvOJWAhi5ePPAOVj2hGXR5UoOBy+risYXL5f7jSEs=",
      "url": "_framework/System.Reflection.Emit.Lightweight.y6m6mumstk.wasm"
    },
    {
      "hash": "sha256-b7bk82rKcT1aGFTKlDt0jwUki0dp/zdmv/Gw2LoVRLo=",
      "url": "_framework/System.Reflection.Emit.vkgiaaugx1.wasm"
    },
    {
      "hash": "sha256-IKhurCnF5B3qAARQ3pEAm/NEC6kpcNG+uQYAnko/844=",
      "url": "_framework/System.Reflection.Extensions.wo2hcpmxue.wasm"
    },
    {
      "hash": "sha256-uTr77i81DOTtJty0Hd+vEAgCv3tstsXVYFOi+5L6RZQ=",
      "url": "_framework/System.Reflection.Metadata.rb69ptrhww.wasm"
    },
    {
      "hash": "sha256-KMsrgRl0dYWSqy7QaAP+s14aRp639FhwwS/zMnmVco0=",
      "url": "_framework/System.Reflection.Primitives.owgpnbdf2l.wasm"
    },
    {
      "hash": "sha256-8r+/FY/fXGriEJvQAEs31lpJs1fVlMELkFu3rElB4c0=",
      "url": "_framework/System.Reflection.TypeExtensions.ugbwir69mf.wasm"
    },
    {
      "hash": "sha256-kqekkRwTvGbeYIN/rpzcg3Hy7vSlTVZqAj4hf146D38=",
      "url": "_framework/System.Reflection.qleunr7uwh.wasm"
    },
    {
      "hash": "sha256-tg75v3zEbyafe7MwxAfIy7tabquNHcGgcQzp7OE4M/E=",
      "url": "_framework/System.Resources.Reader.uruq34mgp9.wasm"
    },
    {
      "hash": "sha256-vrnAOfPb5f+fVRjwBvtzFQ/YHAsnslC+riXnFLWVQ5Q=",
      "url": "_framework/System.Resources.ResourceManager.ux0uqrk07f.wasm"
    },
    {
      "hash": "sha256-Avssk6Q6nPIys2x6qzxQ8BNQcCQrrUpvdhZ84HloP2Q=",
      "url": "_framework/System.Resources.Writer.ayvphjz6cz.wasm"
    },
    {
      "hash": "sha256-R2xN8fQNYbNEFW/ndhZMLvrGyCmpUM0zkS3ao+AtIVk=",
      "url": "_framework/System.Runtime.3xyek4ymus.wasm"
    },
    {
      "hash": "sha256-5IqxKFaPcUQQJeVYV30anNXiyjFpjZbD/QD1oIfRbW4=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.4khgy7b9q5.wasm"
    },
    {
      "hash": "sha256-uafmeKGDofHtfnWdaLlXCEyBRmWr4ocT40PIx4bkODw=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.3p4mn0ysh7.wasm"
    },
    {
      "hash": "sha256-KVy3Au7zzbxAXw64cSdWoQda+/SyN4CFaA4OOpmTN/c=",
      "url": "_framework/System.Runtime.Extensions.hqrbzmad40.wasm"
    },
    {
      "hash": "sha256-PCfRJbHhHO2l7JI8TPnhjD57TbuMdc2lcy1GolvS/t8=",
      "url": "_framework/System.Runtime.Handles.094lsx5f6b.wasm"
    },
    {
      "hash": "sha256-XhjEQgyuvVVNDlut/M5ewXilWwBm38fT0VxNZ3tJucU=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.2fk83jnq2u.wasm"
    },
    {
      "hash": "sha256-nYASmt+A+meSBicMRy6t4RJMXkeYPocbQYhud/qOBb0=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.zk7cyjozjl.wasm"
    },
    {
      "hash": "sha256-qOBxhbyzYHSJJvCvrJYMLYaQqMCAw1CKKEAsfleNJxE=",
      "url": "_framework/System.Runtime.InteropServices.ow07zn60hq.wasm"
    },
    {
      "hash": "sha256-GuNaJIl6lnC9lk4Q2iLg6dRLzSugGh44/uidf/eQNw0=",
      "url": "_framework/System.Runtime.Intrinsics.abl8jzy2z5.wasm"
    },
    {
      "hash": "sha256-bCOSvmP1m1FitXKv4m5sK1tx3SZdqFAcNatQLNOcReQ=",
      "url": "_framework/System.Runtime.Loader.k6sziqro6l.wasm"
    },
    {
      "hash": "sha256-HNAtKss75b2nkPLip3F+U1VbIX/6sQVsCaEe4ZamZKU=",
      "url": "_framework/System.Runtime.Numerics.4sfsxs0184.wasm"
    },
    {
      "hash": "sha256-2/5tX+9aAROqyV3Gp87DXLPVgHjcSNMdj/M8qSs2MZw=",
      "url": "_framework/System.Runtime.Serialization.50ik98aw1y.wasm"
    },
    {
      "hash": "sha256-vboOwOhD/gbbsDpkMxu0px1U9O36/D6NghHdMZxr1dI=",
      "url": "_framework/System.Runtime.Serialization.Formatters.7jpg0ga6bl.wasm"
    },
    {
      "hash": "sha256-8WRhncMH91WyN+vVmKRRBjkJNO7nzNqsGV9qTqLadws=",
      "url": "_framework/System.Runtime.Serialization.Json.b9kelqipe5.wasm"
    },
    {
      "hash": "sha256-r/7Gr7G4865fm8nv+Zv7x730Lka+RfcQ1u8g54ZMzlU=",
      "url": "_framework/System.Runtime.Serialization.Primitives.7evbfnumk2.wasm"
    },
    {
      "hash": "sha256-xaAEBMpgtnD140gnoGe6xFV851Adu4NnDwNr37Bkp2U=",
      "url": "_framework/System.Runtime.Serialization.Xml.n18222koyv.wasm"
    },
    {
      "hash": "sha256-qpVdOl34HEIb11RHSmSsOU5aqgk+qVT/di7eIT5EmEM=",
      "url": "_framework/System.Security.AccessControl.evo3dex3li.wasm"
    },
    {
      "hash": "sha256-away8OWDKsXkx+caSJCIqIF960RdTHyKxUAh6R8nZg4=",
      "url": "_framework/System.Security.Claims.ti7239sow1.wasm"
    },
    {
      "hash": "sha256-fMuBZarIRT2bHaHDWxwfg7M79y/Hw6Rmfj43i69/IWY=",
      "url": "_framework/System.Security.Cryptography.Algorithms.s2uh2c5xhr.wasm"
    },
    {
      "hash": "sha256-B/kFISr4LyGs1fZFDaOpGA+2rXhTsVhhuoNisFUi6gA=",
      "url": "_framework/System.Security.Cryptography.Cng.hm1r29oxon.wasm"
    },
    {
      "hash": "sha256-QHeDW1MTzz02nuoEzJ+hFvIZIQJsMg8ZLcVp4xG/1bc=",
      "url": "_framework/System.Security.Cryptography.Csp.ggb5qptuf7.wasm"
    },
    {
      "hash": "sha256-xgBbSHtXDHx9SGmzQaxkW7banlVqCIUIQMNFY6pLJCU=",
      "url": "_framework/System.Security.Cryptography.Encoding.yh0hc21gri.wasm"
    },
    {
      "hash": "sha256-B9u2Cd8xgposRMtcrAR3auTgDAfMdYK3BX8XukBZPtE=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.r3wu1ztcba.wasm"
    },
    {
      "hash": "sha256-zkHfKDP1kDQ8wLmGtmjkHQFsdwp0Nc74QLEXyt2+uKY=",
      "url": "_framework/System.Security.Cryptography.Primitives.6qe15r9pvd.wasm"
    },
    {
      "hash": "sha256-n9SNwbSWwcA5UBdCYw58hAokTEZkR3//wjsV+uj6Vd8=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.7m0uydcoo5.wasm"
    },
    {
      "hash": "sha256-AKUvBmeSVO2GvHWGAaPt4oF/MImHH6hRckiZho7AdYM=",
      "url": "_framework/System.Security.Cryptography.c9z2k61vp3.wasm"
    },
    {
      "hash": "sha256-vs8B1VDbNvo30qixfdoZ9bUlf+FGDeMojs93zVNrB50=",
      "url": "_framework/System.Security.Principal.Windows.u888ksn8ls.wasm"
    },
    {
      "hash": "sha256-fxNbv1whb19KKDOvZpz85SwxwXJ2Pd8t5u0uIp6/cyg=",
      "url": "_framework/System.Security.Principal.blw61qa9dp.wasm"
    },
    {
      "hash": "sha256-/aPWw42WvhCcPxd3aLU+tefLQCsXVDyxJNG28TtolLY=",
      "url": "_framework/System.Security.SecureString.nv9oozdjiy.wasm"
    },
    {
      "hash": "sha256-mx2i9RLgmhiug5g1eFFD8icejz0q0iybpXNPOLACG4g=",
      "url": "_framework/System.Security.d2p6izeyw0.wasm"
    },
    {
      "hash": "sha256-MTOk8Qs+UMEoNm9byvIxVsr12I9C5z7jXaU6pGknuFA=",
      "url": "_framework/System.ServiceModel.Web.lf0cqzqdki.wasm"
    },
    {
      "hash": "sha256-VQgLflQMGLGYXqgouNsYJOFoE92gzPgH8ltqh2N3aWQ=",
      "url": "_framework/System.ServiceProcess.3ubr73b6f9.wasm"
    },
    {
      "hash": "sha256-3c9cLnCWlJ+gGb8lD6l/lA6rLfhm4ZWDaBnSRKcFZAE=",
      "url": "_framework/System.Text.Encoding.CodePages.zomtsbb76b.wasm"
    },
    {
      "hash": "sha256-TrXoyF9vCp/NzEkQ5D1OGafpRXx4nVMFgLpWVZpwMDk=",
      "url": "_framework/System.Text.Encoding.Extensions.e53rqaozre.wasm"
    },
    {
      "hash": "sha256-9HNmX0rxIbvpzaAZXHehBYxcHvlfWJMiCkji7DY2+hw=",
      "url": "_framework/System.Text.Encoding.o1hfsv9qlu.wasm"
    },
    {
      "hash": "sha256-9/swWl8AnCNwwYSmQ+A9IqBcPvjbijOkQFokeehunHY=",
      "url": "_framework/System.Text.Encodings.Web.n0i71xa9cg.wasm"
    },
    {
      "hash": "sha256-gKQoq2TmWZHGZQd8hkmh3AfspR0MUAtKSk4ST3tM/+w=",
      "url": "_framework/System.Text.Json.knzc464mux.wasm"
    },
    {
      "hash": "sha256-8Kg0FwCfluYLqO5mVBejr0/F3lNodXpQn4Z9KwRqGms=",
      "url": "_framework/System.Text.RegularExpressions.4nbklv63lu.wasm"
    },
    {
      "hash": "sha256-DWq8M5IX4Vewh7isGv+uH4A8YjUZLBdHbQfTMk4a3e0=",
      "url": "_framework/System.Threading.3c4knfr297.wasm"
    },
    {
      "hash": "sha256-0n5a2diAnQ4ZETo8uHz36YszvnwY1RweLWkh60SCeZc=",
      "url": "_framework/System.Threading.Channels.ayoqqlvjcs.wasm"
    },
    {
      "hash": "sha256-AkmCnUeB1yrEcG6FH6Ho1sAzvX01DWORLEtO2Vbb8kw=",
      "url": "_framework/System.Threading.Overlapped.irqizvcv31.wasm"
    },
    {
      "hash": "sha256-fmfeR31i3mnuefo1pDQCwBi/2D9J6+5ldRk3Fm/TR0I=",
      "url": "_framework/System.Threading.Tasks.Dataflow.ed6xenn8uh.wasm"
    },
    {
      "hash": "sha256-ZETqIlxhaV7eM/dvuEofSBVVT482qa8BK3OsEsbiKls=",
      "url": "_framework/System.Threading.Tasks.Extensions.w7snxjuw5j.wasm"
    },
    {
      "hash": "sha256-7tA312g7QnhiY1h3GQhyfvjSSQUzN0h30PNmPgHstLc=",
      "url": "_framework/System.Threading.Tasks.Parallel.eo4laf6ebb.wasm"
    },
    {
      "hash": "sha256-xGXy/B8OtnyWstZsQKVFxkSWTd+KmXRkEwR7ddG/vUw=",
      "url": "_framework/System.Threading.Tasks.w3vja3w9hf.wasm"
    },
    {
      "hash": "sha256-77vlMh7qDl/2RTe1a/dH44Bl842LWbOd16+HDdh2S44=",
      "url": "_framework/System.Threading.Thread.lbfyamq3pf.wasm"
    },
    {
      "hash": "sha256-bkPMOwU7JT3mp88F0Eil6iRMdrnIQmIAq3xAy/vBfc8=",
      "url": "_framework/System.Threading.ThreadPool.6bwc2zapk1.wasm"
    },
    {
      "hash": "sha256-vS77s/1joOt2YRAfJq6KSzJv7EbFtlBdJX0TkLuFo9c=",
      "url": "_framework/System.Threading.Timer.9tyefqve9u.wasm"
    },
    {
      "hash": "sha256-lrae5SdK7DLg+9P4xJsf6lK2b8cjLanNjs8AxwRKzcs=",
      "url": "_framework/System.Transactions.6p6q5sdzmu.wasm"
    },
    {
      "hash": "sha256-tbALeIcdYP0xjqwxu/Iv9ak39Lw4x3HTyy+Y15Sr1Kg=",
      "url": "_framework/System.Transactions.Local.93c6ugdhar.wasm"
    },
    {
      "hash": "sha256-+sYIfpSJd7r9vXODp3LKKAj1rtxYTp7iwZSISjGvixg=",
      "url": "_framework/System.ValueTuple.afu4msg8b6.wasm"
    },
    {
      "hash": "sha256-nNhzHENWN0phmIhylpgZHeuOAnmnYAHqR595n5aehz0=",
      "url": "_framework/System.Web.0fkd00r6qh.wasm"
    },
    {
      "hash": "sha256-ejdl48nEovVP/OumKk090ucxButUl01RG54sliuGRqM=",
      "url": "_framework/System.Web.HttpUtility.q8oze55etw.wasm"
    },
    {
      "hash": "sha256-2GmHT0vxoxVwRTt40T1Sj2dfAfyaM7spJ+P7BmrQegQ=",
      "url": "_framework/System.Windows.gqex1c1l85.wasm"
    },
    {
      "hash": "sha256-a6esnAYlmOB9EO/Xkkwrlj1o2APqcA/dZMwZAY2FfhY=",
      "url": "_framework/System.Xml.3m9nz9tq05.wasm"
    },
    {
      "hash": "sha256-zB/vv4el1g+i2G0gYh9egciGMmdEtnJgZL+d0Bej0ps=",
      "url": "_framework/System.Xml.Linq.g53db9y76h.wasm"
    },
    {
      "hash": "sha256-JOjRIP/kt1pnWI+z3J3dsUwiBfZJ+R7iYlnkCBWlnGc=",
      "url": "_framework/System.Xml.ReaderWriter.cuuc1o8pb2.wasm"
    },
    {
      "hash": "sha256-seXNN8v0t51lnoUdybahLOnCm/0YFLd9AIPpIBLgSRc=",
      "url": "_framework/System.Xml.Serialization.xwlribuwgr.wasm"
    },
    {
      "hash": "sha256-shbjkHMTxmrjwNmw0rXmROE34VEoiUIlzs0cg07ZgzY=",
      "url": "_framework/System.Xml.XDocument.mql1588o0y.wasm"
    },
    {
      "hash": "sha256-NCm28u65n1KrrFXH++RGJdybb8QR5nti86Qlc5Clo78=",
      "url": "_framework/System.Xml.XPath.XDocument.81ye7boh3q.wasm"
    },
    {
      "hash": "sha256-ZWnDu4Xj29W0rhkpUiWXw6QN0hi5Ilhto60mLz0Thik=",
      "url": "_framework/System.Xml.XPath.jicxtf86kr.wasm"
    },
    {
      "hash": "sha256-pnRaAblZ9dKoGaP+MA4Xs5k6EmrZEmJ7TS+OlOexsAg=",
      "url": "_framework/System.Xml.XmlDocument.ubn5i58yul.wasm"
    },
    {
      "hash": "sha256-G2vZbvzaH1f716+4inPkd52we1P38bt348WfrnoVrGQ=",
      "url": "_framework/System.Xml.XmlSerializer.xhq3csvynu.wasm"
    },
    {
      "hash": "sha256-c6oVK0Qfmq4yfeYcJFqGlqys3Mx4H0im/NFGSjMl8Cs=",
      "url": "_framework/System.jcn51drkym.wasm"
    },
    {
      "hash": "sha256-Lg5W8BM50Cpl1dgTrG9RQOrBRKOJq6H1t5sH3yf4KDU=",
      "url": "_framework/WindowsBase.i7qip04bb5.wasm"
    },
    {
      "hash": "sha256-JB0qyJo8xlljzi4ZxM6NTbszGkIjQy2HEZ7HBq1B83s=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-T1vT02oTgL1ZyvL5isJPjfUyEmsUizbUY23kldI8wZ4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-U5Ze8LgeQhQdPtpMfG+ihMkdpGNJqs9sMe2Bdlgzo7k=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-p9eEzXhQIsI0a5bBJhfzW15iRafgplTxT8XrO5FiH9o=",
      "url": "_framework/dotnet.native.noby4tlk4d.js"
    },
    {
      "hash": "sha256-Po2dalLvTpf5jAS+jt0TzuBYybYiL1F6qAacZJ8UAdo=",
      "url": "_framework/dotnet.native.qe75a9vfqn.wasm"
    },
    {
      "hash": "sha256-6QIZYgG+ftoT9N1H1EEJeXIhD/qbKqEcnmawDskiwdI=",
      "url": "_framework/dotnet.runtime.9o45ky8ejm.js"
    },
    {
      "hash": "sha256-5tmnUNd+LbNMJ9y5ynE3RNMd/g/1UvnAgVrznidh4EA=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-ku4DyQX7IfTdwPwDlrz9odvCs4mrgsJl0fNaqY56KOI=",
      "url": "_framework/mscorlib.ijjuvl21w4.wasm"
    },
    {
      "hash": "sha256-I7arRnyxWh5PItslQKjzLIG7EpohJACm7p/7K8eD0YA=",
      "url": "_framework/netstandard.jgp13znru0.wasm"
    },
    {
      "hash": "sha256-R2CKgZaJhsxfdwgBj3ZTHIG4t+R4rw179XXNknBAR44=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-2eJUQoWyLk9CH+QWvBf7W3/sLXLIMdb+xBkFgcWNWPs=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-+oqxXeRdsR1u4YUsDlPJ5AE4Pyhg6ph7wVVB3U//qEA=",
      "url": "index.html"
    },
    {
      "hash": "sha256-nREmhBocGdvedPowujunqFJlnp2C3oKorIhBP7gn3AU=",
      "url": "manifest.webmanifest"
    }
  ]
};
